## 2. Previewing A Table Using SELECT ##

SELECT * from recent_grads limit 10;

## 3. Filtering Rows Using WHERE ##

select Major, ShareWomen from  recent_grads
where ShareWomen < 0.5

## 4. Expressing Multiple Filter Criteria Using AND ##

SELECT Major, Major_category, Median, ShareWomen from recent_grads
where ShareWomen >= 0.5
and Median > 50000

## 5. Returning One of Several Conditions With OR ##

SELECT Major, Median, Unemployed from recent_grads
where Median >= 10000 or Median < 1000
LIMIT 20

## 6. Grouping Operators With Parentheses ##

SELECT Major, Major_category, ShareWomen, Unemployment_rate
FROM recent_grads
where Major_category = 'Engineering' and (ShareWomen >= 0.5 OR (Unemployment_rate <0.051))

## 7. Ordering Results Using ORDER BY ##

SELECT Major, ShareWomen, Unemployment_rate from recent_grads
WHERE ShareWomen > 0.3
and Unemployment_rate < .1
ORDER BY ShareWomen DESC


## 8. Practice Writing A Query ##

SELECT Major_category, Major, Unemployment_rate FROM recent_grads
WHERE Major_category IN ('Engineering', 'Physical Sciences')
ORDER BY Unemployment_rate ASC